// 原本大小的主包
const entry = {};

entry.path = {
    // 'game/js': {
        // 'project': './game/js/project.js',
    //     'assetsmanager.min': './game/js/assetsmanager.min.js',
    //     'astar.min': './game/js/astar.min.js',
    //     'default.thm': './game/js/default.thm.js',
    //     'default.thm.min': './game/js/default.thm.min.js',
    //     'dragonBones.min': './game/js/dragonBones.min.js',
    //     'egret.min': './game/js/egret.min.js',
    //     'eui.min': './game/js/eui.min.js',
    //     'ext.min': './game/js/ext.min.js',
    //     'game.min': './game/js/game.min.js',
    //     // 'jszip.min': './game/js/jszip.min.js', //太大没混淆
    //     'md5.min': './game/js/md5.min.js',
    //     'platform.min': './game/js/platform.min.js',
    //     // 'protobuf-bundles.min': './game/js/protobuf-bundles.min.js',
    //     // 'protobuf-library.min': './game/js/protobuf-library.min.js',
    //     // 'puremvc.min': './game/js/puremvc.min.js', //混淆失败
    //     'socket.min': './game/js/socket.min.js',
        // 'tween.min': './game/js/tween.min.js'
    // },
    // 'game/libray': {
    //     'binary': './game/library/binary.js',
    //     'file-util': './game/library/file-util.js',
    //     'image': './game/library/image.js',
    //     'sound': './game/library/sound.js',
    //     'text': './game/library/text.js'
    // },
    'game/stage1': {
        'test': './game/stage1/test.js',
        // 'main': './game/stage1/main.js'
    },
    // '': {
    //     'EgretSubPackageLoading': './game/EgretSubPackageLoading.js'
    //     // 'bhSdk': './game/bhSdk.js',
    //     // 'change': './game/change.js',
    // }
    
};

module.exports = entry;