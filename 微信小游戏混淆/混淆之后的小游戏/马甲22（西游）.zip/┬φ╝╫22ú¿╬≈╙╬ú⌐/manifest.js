require("./js/index.js")
require("./publish/init_local.js")
require("./publish/start.js")
require("./EgretSubPackageLoading.js");